package com.mycompany.oratile_jabanyane_prog6112_assign2;

import com.mycompany.oratile_jabanyane_prog6112_assign2.Oratile_Jabanyane_Prog6112_Assign2.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class CabinetTest {

    private Cabinet cabinet;

    @BeforeEach
    public void setUp() {
        cabinet = new Cabinet();
    }

    // ---- cost calculations ----

    @Test public void woundedNoTheatre() {
        Wounded w = new Wounded("R01", "Tusker", "African Elephant", "Kruger", "A",
                5, 2000, Journey.LOGGED, "Snare wound", 8500, false);
        assertEquals(18500, w.grandTotal(), 0.001);
    }

    @Test public void woundedWithTheatre() {
        Wounded w = new Wounded("R02", "Tusker", "African Elephant", "Kruger", "A",
                5, 2000, Journey.LOGGED, "Snare wound", 8500, true);
        assertEquals(23500, w.grandTotal(), 0.001);
    }

    @Test public void orphanNoGuardian() {
        Orphan o = new Orphan("R03", "Nandi", "White Rhino", "Hluhluwe", "B",
                10, 600, Journey.LOGGED, 4, 3000, false);
        assertEquals(9000, o.grandTotal(), 0.001);
    }

    @Test public void orphanWithGuardian() {
        Orphan o = new Orphan("R04", "Nandi", "White Rhino", "Hluhluwe", "B",
                10, 600, Journey.LOGGED, 4, 3000, true);
        assertEquals(11500, o.grandTotal(), 0.001);
    }

    @Test public void protectedNoTaskForce() {
        Protected p = new Protected("R05", "Shadow", "Black Rhino", "Addo", "C",
                7, 800, Journey.LOGGED, "Critically Endangered", 12000, false);
        assertEquals(17600, p.grandTotal(), 0.001);
    }

    @Test public void protectedWithTaskForce() {
        Protected p = new Protected("R06", "Shadow", "Black Rhino", "Addo", "C",
                7, 800, Journey.LOGGED, "Critically Endangered", 12000, true);
        assertEquals(25600, p.grandTotal(), 0.001);
    }

    // ---- priority tiers ----

    @Test public void woundedCritical() {
        Wounded w = new Wounded("R07", "Lion", "African Lion", "Kgalagadi", "D",
                3, 500, Journey.LOGGED, "Gunshot", 15000, true);
        assertEquals("Critical", w.severity());
    }

    @Test public void woundedHigh() {
        Wounded w = new Wounded("R08", "Lion", "African Lion", "Kgalagadi", "D",
                3, 500, Journey.LOGGED, "Fracture", 13000, false);
        assertEquals("High", w.severity());
    }

    @Test public void woundedMedium() {
        Wounded w = new Wounded("R09", "Lion", "African Lion", "Kgalagadi", "D",
                3, 500, Journey.LOGGED, "Wound", 5000, false);
        assertEquals("Medium", w.severity());
    }

    @Test public void woundedLow() {
        Wounded w = new Wounded("R10", "Lion", "African Lion", "Kgalagadi", "D",
                3, 500, Journey.LOGGED, "Cut", 1000, false);
        assertEquals("Low", w.severity());
    }

    @Test public void orphanCritical() {
        Orphan o = new Orphan("R11", "Baby Elephant", "African Elephant", "Addo", "E",
                5, 400, Journey.LOGGED, 2, 3000, true);
        assertEquals("Critical", o.severity());
    }

    @Test public void orphanHigh() {
        Orphan o = new Orphan("R12", "Baby Elephant", "African Elephant", "Addo", "E",
                5, 400, Journey.LOGGED, 2, 3000, false);
        assertEquals("High", o.severity());
    }

    @Test public void orphanMedium() {
        Orphan o = new Orphan("R13", "Young Elephant", "African Elephant", "Addo", "E",
                5, 400, Journey.LOGGED, 8, 3000, false);
        assertEquals("Medium", o.severity());
    }

    @Test public void orphanLow() {
        Orphan o = new Orphan("R14", "Juvenile", "African Elephant", "Addo", "E",
                5, 400, Journey.LOGGED, 18, 3000, false);
        assertEquals("Low", o.severity());
    }

    @Test public void protectedCritical() {
        Protected p = new Protected("R15", "Rhino", "Black Rhino", "Kruger", "F",
                6, 600, Journey.LOGGED, "Critically Endangered", 9000, true);
        assertEquals("Critical", p.severity());
    }

    @Test public void protectedHigh() {
        Protected p = new Protected("R16", "Rhino", "Black Rhino", "Kruger", "F",
                6, 600, Journey.LOGGED, "Critically Endangered", 9000, false);
        assertEquals("High", p.severity());
    }

    @Test public void protectedMedium() {
        Protected p = new Protected("R17", "Rhino", "Black Rhino", "Kruger", "F",
                6, 600, Journey.LOGGED, "Endangered", 9000, false);
        assertEquals("Medium", p.severity());
    }

    @Test public void protectedLow() {
        Protected p = new Protected("R18", "Rhino", "Black Rhino", "Kruger", "F",
                6, 600, Journey.LOGGED, "Vulnerable", 9000, false);
        assertEquals("Low", p.severity());
    }

    // ---- status transitions ----

    @Test public void engageMarksEngaged() {
        Wounded w = new Wounded("R19", "Zebra", "Plains Zebra", "Etosha", "G",
                4, 150, Journey.LOGGED, "Sprain", 1200, false);
        w.engage();
        assertEquals(Journey.ENGAGED, w.phase());
    }

    @Test public void settleMarksSettled() {
        Orphan o = new Orphan("R20", "Baby Giraffe", "Giraffe", "Etosha", "G",
                4, 150, Journey.LOGGED, 4, 800, false);
        o.settle();
        assertEquals(Journey.SETTLED, o.phase());
    }

    // ---- search ----

    @Test public void findExisting() {
        Wounded w = new Wounded("R21", "Leopard", "African Leopard", "Sabie", "H",
                2, 250, Journey.LOGGED, "Snare", 3000, false);
        cabinet.lodge(w);
        assertNotNull(cabinet.query("R21"));
        assertEquals("Leopard", cabinet.query("R21").creature());
    }

    @Test public void findMissing() {
        assertNull(cabinet.query("R999"));
    }

    @Test public void findCaseInsensitive() {
        Orphan o = new Orphan("r22", "Baby Lion", "African Lion", "Kgalagadi", "I",
                3, 200, Journey.LOGGED, 2, 900, true);
        cabinet.lodge(o);
        assertNotNull(cabinet.query("R22"));
    }

    // ---- duplicates and validation ----

    @Test public void rejectDuplicate() {
        cabinet.lodge(new Wounded("R23", "Buffalo", "African Buffalo", "Hluhluwe", "J",
                5, 180, Journey.LOGGED, "Horn", 2500, false));
        Wounded clash = new Wounded("R23", "Buffalo", "African Buffalo", "Hluhluwe", "J",
                5, 180, Journey.LOGGED, "Horn", 2500, false);
        assertThrows(IllegalArgumentException.class, () -> cabinet.lodge(clash));
    }

    @Test public void rejectDuplicateCaseInsensitive() {
        cabinet.lodge(new Protected("R24", "Pangolin", "Ground Pangolin", "Limpopo", "K",
                4, 350, Journey.LOGGED, "Endangered", 3000, false));
        Protected clash = new Protected("r24", "Pangolin", "Ground Pangolin", "Limpopo", "K",
                4, 350, Journey.LOGGED, "Endangered", 3000, false);
        assertThrows(IllegalArgumentException.class, () -> cabinet.lodge(clash));
    }

    @Test public void rejectBlankId() {
        Wounded w = new Wounded("   ", "Bird", "Eagle", "Drakensberg", "L",
                2, 100, Journey.LOGGED, "Wing", 500, false);
        assertThrows(IllegalArgumentException.class, () -> cabinet.lodge(w));
    }

    @Test public void rejectNull() {
        assertThrows(IllegalArgumentException.class, () -> cabinet.lodge(null));
    }

    // ---- totals ----

    @Test public void totalsAcrossTwoCases() {
        cabinet.lodge(new Wounded("R25", "Elephant", "African Elephant", "Kruger", "A",
                5, 100, Journey.LOGGED, "Leg", 2000, false)); // 2500
        cabinet.lodge(new Orphan("R26", "Baby Rhino", "White Rhino", "Hluhluwe", "B",
                10, 200, Journey.LOGGED, 6, 1500, true)); // 6000

        assertEquals(2, cabinet.tally());
        assertEquals(8500, cabinet.totalWorth(), 0.001);
    }
}