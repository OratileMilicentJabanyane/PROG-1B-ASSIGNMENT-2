package com.mycompany.oratile_jabanyane_prog6112_assign2;

import javax.swing.*;
import java.awt.Dimension;
import java.text.DecimalFormat;
import java.util.ArrayList;

public class Oratile_Jabanyane_Prog6112_Assign2 {

    public static void main(String[] args) {
        FrontDesk.open();
    }

    // Common contract every rescue case must honour.
    interface Journey {
        String LOGGED  = "New Rescue";
        String ENGAGED = "Rescue in Progress";
        String MONITOR = "Under Observation";
        String SETTLED = "Rescue Completed";

        void engage();
        void settle();
        String profile();
    }

    // Abstract base: shared state plus abstract type-specific behaviour.
    static abstract class RescueCase implements Journey {

        private String ticket, creature, kind, place, keeper, phase;
        private int days;
        private double rate;

        RescueCase(String ticket, String creature, String kind, String place,
                   String keeper, int days, double rate, String phase) {
            this.ticket = ticket;
            this.creature = creature;
            this.kind = kind;
            this.place = place;
            this.keeper = keeper;
            this.days = days;
            this.rate = rate;
            this.phase = phase;
        }

        String ticket()   { return ticket; }
        String creature() { return creature; }
        String kind()     { return kind; }
        String place()    { return place; }
        String keeper()   { return keeper; }
        String phase()    { return phase; }
        int days()        { return days; }
        double rate()     { return rate; }
        void phase(String p) { phase = p; }

        // Base fee = days spent multiplied by the daily rate.
        double baseFee() { return days * rate; }

        // Rands with a space as the thousands separator and two decimals.
        static String rands(double v) {
            DecimalFormat f = new DecimalFormat("#,##0.00");
            return "R" + f.format(v).replace(",", " ");
        }

        abstract double grandTotal();
        abstract String severity();
        abstract String label();
        abstract String specifics();
    }

    // Injured rescue: base + medical + R5 000 if theatre is required.
    // Severity: Critical if theatre AND medical >= 12000; High if either;
    //           Medium if medical >= 4000; otherwise Low.
    static class Wounded extends RescueCase {

        private String cause;
        private double medical;
        private boolean theatre;

        Wounded(String ticket, String creature, String kind, String place, String keeper,
                int days, double rate, String phase,
                String cause, double medical, boolean theatre) {
            super(ticket, creature, kind, place, keeper, days, rate, phase);
            this.cause = cause;
            this.medical = medical;
            this.theatre = theatre;
        }

        String cause()      { return cause; }
        double medical()    { return medical; }
        boolean theatre()   { return theatre; }

        @Override double grandTotal() {
            return baseFee() + medical + (theatre ? 5000.0 : 0.0);
        }

        @Override String severity() {
            if (theatre && medical >= 12000) return "Critical";
            if (theatre || medical >= 12000) return "High";
            if (medical >= 4000)             return "Medium";
            return "Low";
        }

        @Override String label() { return "Injured Animal Rescue"; }

        @Override String specifics() {
            return "Cause of Injury       : " + cause + "\n" +
                   "Medical Cost          : " + rands(medical) + "\n" +
                   "Theatre Required      : " + (theatre ? "Yes" : "No");
        }

        @Override public void engage() { phase(ENGAGED); }
        @Override public void settle() { phase(SETTLED); }

        @Override public String profile() {
            return "Case ID           : " + ticket() + "\n" +
                   "Type              : " + label() + "\n" +
                   "Species           : " + kind() + "\n" +
                   "Ranger            : " + keeper() + "\n" +
                   "Priority          : " + severity() + "\n" +
                   "Status            : " + phase() + "\n" +
                   "Total Cost        : " + rands(grandTotal());
        }
    }

    // Orphaned rescue: base + feeding + R2 500 if a guardian is required.
    // Severity: Critical if age <= 2 AND guardian; High if either;
    //           Medium if age <= 9; otherwise Low.
    static class Orphan extends RescueCase {

        private int months;
        private double feeding;
        private boolean guardian;

        Orphan(String ticket, String creature, String kind, String place, String keeper,
               int days, double rate, String phase,
               int months, double feeding, boolean guardian) {
            super(ticket, creature, kind, place, keeper, days, rate, phase);
            this.months = months;
            this.feeding = feeding;
            this.guardian = guardian;
        }

        int months()        { return months; }
        double feeding()    { return feeding; }
        boolean guardian()  { return guardian; }

        @Override double grandTotal() {
            return baseFee() + feeding + (guardian ? 2500.0 : 0.0);
        }

        @Override String severity() {
            if (months <= 2 && guardian) return "Critical";
            if (months <= 2 || guardian) return "High";
            if (months <= 9)             return "Medium";
            return "Low";
        }

        @Override String label() { return "Orphaned Animal Rescue"; }

        @Override String specifics() {
            return "Age (months)          : " + months + "\n" +
                   "Feeding Cost          : " + rands(feeding) + "\n" +
                   "Guardian Required     : " + (guardian ? "Yes" : "No");
        }

        @Override public void engage() { phase(ENGAGED); }
        @Override public void settle() { phase(SETTLED); }

        @Override public String profile() {
            return "Case ID           : " + ticket() + "\n" +
                   "Type              : " + label() + "\n" +
                   "Species           : " + kind() + "\n" +
                   "Ranger            : " + keeper() + "\n" +
                   "Priority          : " + severity() + "\n" +
                   "Status            : " + phase() + "\n" +
                   "Total Cost        : " + rands(grandTotal());
        }
    }

    // Endangered rescue: base + security + R8 000 if a task force is required.
    // Severity: Critical if task force AND critically endangered; High if either;
    //           Medium if endangered; otherwise Low.
    static class Protected extends RescueCase {

        private String status;
        private double security;
        private boolean taskForce;

        Protected(String ticket, String creature, String kind, String place, String keeper,
                  int days, double rate, String phase,
                  String status, double security, boolean taskForce) {
            super(ticket, creature, kind, place, keeper, days, rate, phase);
            this.status = status;
            this.security = security;
            this.taskForce = taskForce;
        }

        String status()       { return status; }
        double security()     { return security; }
        boolean taskForce()   { return taskForce; }

        @Override double grandTotal() {
            return baseFee() + security + (taskForce ? 8000.0 : 0.0);
        }

        @Override String severity() {
            boolean critical = "Critically Endangered".equalsIgnoreCase(status);
            if (taskForce && critical) return "Critical";
            if (taskForce || critical) return "High";
            if ("Endangered".equalsIgnoreCase(status)) return "Medium";
            return "Low";
        }

        @Override String label() { return "Endangered Species Rescue"; }

        @Override String specifics() {
            return "Conservation Status   : " + status + "\n" +
                   "Security Cost         : " + rands(security) + "\n" +
                   "Task Force            : " + (taskForce ? "Yes" : "No");
        }

        @Override public void engage() { phase(ENGAGED); }
        @Override public void settle() { phase(SETTLED); }

        @Override public String profile() {
            return "Case ID           : " + ticket() + "\n" +
                   "Type              : " + label() + "\n" +
                   "Species           : " + kind() + "\n" +
                   "Ranger            : " + keeper() + "\n" +
                   "Priority          : " + severity() + "\n" +
                   "Status            : " + phase() + "\n" +
                   "Total Cost        : " + rands(grandTotal());
        }
    }

    // Business layer: cases kept in an ArrayList with unique-ID enforcement.
    static class Cabinet {

        private final ArrayList<RescueCase> files = new ArrayList<>();

        void lodge(RescueCase rc) {
            if (rc == null) throw new IllegalArgumentException("Case cannot be null.");
            String id = rc.ticket();
            if (id == null || id.trim().isEmpty())
                throw new IllegalArgumentException("Case ID cannot be blank.");
            if (query(id) != null)
                throw new IllegalArgumentException("Case ID already filed: " + id);
            files.add(rc);
        }

        RescueCase query(String id) {
            if (id == null) return null;
            for (RescueCase rc : files)
                if (rc.ticket().equalsIgnoreCase(id.trim())) return rc;
            return null;
        }

        boolean changePhase(String id, String phase) {
            RescueCase rc = query(id);
            if (rc == null) return false;
            rc.phase(phase);
            return true;
        }

        ArrayList<RescueCase> files() { return files; }
        int tally() { return files.size(); }

        double totalWorth() {
            double t = 0;
            for (RescueCase rc : files) t += rc.grandTotal();
            return t;
        }

        boolean filed(String id) { return query(id) != null; }
    }

    // JOptionPane user interface. Delegates every action to Cabinet.
    static class FrontDesk {

        private static final Cabinet cabinet = new Cabinet();

        static void open() {
            boolean live = true;
            while (live) {
                String board =
                        "=====================================\n" +
                        "WILDLIFE RESCUE OPERATIONS SYSTEM\n" +
                        "=====================================\n" +
                        "1. Create Rescue Case\n" +
                        "2. Search Rescue Case\n" +
                        "3. Update Rescue Status\n" +
                        "4. Display All Rescue Cases\n" +
                        "5. Rescue Report\n" +
                        "6. Exit\n" +
                        "=====================================\n" +
                        "Select an option:";

                String chosen = JOptionPane.showInputDialog(null, board, "WildLife SA", JOptionPane.PLAIN_MESSAGE);
                if (chosen == null) { live = false; continue; }

                switch (chosen.trim()) {
                    case "1": newCase();   break;
                    case "2": findCase();  break;
                    case "3": shiftPhase();break;
                    case "4": listCases(); break;
                    case "5": printReport();break;
                    case "6": live = false; notify("Goodbye."); break;
                    default:  notify("Invalid. Choose 1 to 6.");
                }
            }
        }

        private static void newCase() {
            String[] types = {
                "Injured Animal Rescue",
                "Orphaned Animal Rescue",
                "Endangered Species Rescue"
            };
            String choice = (String) JOptionPane.showInputDialog(
                    null, "Select rescue type:", "WildLife SA",
                    JOptionPane.QUESTION_MESSAGE, null, types, types[0]);
            if (choice == null) return;

            String id = prompt("Enter Rescue Case ID:");
            if (id == null) return;
            if (cabinet.filed(id)) { notify("ID already in use."); return; }

            String creature = prompt("Enter Animal Name:");      if (creature == null) return;
            String kind     = prompt("Enter Species:");          if (kind == null) return;
            String place    = prompt("Enter Rescue Location:");  if (place == null) return;
            String keeper   = prompt("Enter Assigned Ranger:");  if (keeper == null) return;
            Integer days    = promptInt("Enter Number of Rescue Days:"); if (days == null) return;
            Double rate     = promptDouble("Enter Daily Care Cost (R):"); if (rate == null) return;

            try {
                RescueCase rc;
                if (choice.equals(types[0])) {
                    String cause = prompt("Enter Injury Description:");           if (cause == null) return;
                    Double med   = promptAmount("Veterinary Treatment Cost (R):"); if (med == null) return;
                    boolean theatre = confirm("Is Surgery Required?");
                    rc = new Wounded(id, creature, kind, place, keeper, days, rate, Journey.LOGGED, cause, med, theatre);
                } else if (choice.equals(types[1])) {
                    Integer months = promptInt("Enter Estimated Age (Months):"); if (months == null) return;
                    Double feed    = promptAmount("Feeding Cost (R):");          if (feed == null) return;
                    boolean guardian = confirm("Is Foster Care Required?");
                    rc = new Orphan(id, creature, kind, place, keeper, days, rate, Journey.LOGGED, months, feed, guardian);
                } else {
                    String status = prompt("Enter Conservation Classification:"); if (status == null) return;
                    Double sec    = promptAmount("Security Cost (R):");           if (sec == null) return;
                    boolean team  = confirm("Is a Specialist Team Required?");
                    rc = new Protected(id, creature, kind, place, keeper, days, rate, Journey.LOGGED, status, sec, team);
                }
                cabinet.lodge(rc);
                notify("Case created.\n\n" + rc.profile());
            } catch (IllegalArgumentException ex) {
                notify(ex.getMessage());
            }
        }

        private static void findCase() {
            String id = prompt("Enter Rescue Case ID to search:");
            if (id == null) return;
            RescueCase rc = cabinet.query(id);
            if (rc == null) { notify("Not found: " + id); return; }
            viewer("Rescue Case Details", expand(rc));
        }

        private static void shiftPhase() {
            String id = prompt("Enter Rescue Case ID to update:");
            if (id == null) return;
            RescueCase rc = cabinet.query(id);
            if (rc == null) { notify("Not found: " + id); return; }

            String[] phases = { Journey.ENGAGED, Journey.MONITOR, Journey.SETTLED, Journey.LOGGED };
            String next = (String) JOptionPane.showInputDialog(
                    null, "Choose new status for " + rc.ticket() + ":",
                    "Update Status", JOptionPane.QUESTION_MESSAGE,
                    null, phases, rc.phase());
            if (next == null) return;

            cabinet.changePhase(id, next);
            notify("Status updated.\n\n" + rc.profile());
        }

        private static void listCases() {
            ArrayList<RescueCase> list = cabinet.files();
            if (list.isEmpty()) { notify("No rescue cases yet."); return; }

            StringBuilder sb = new StringBuilder();
            sb.append("ALL RESCUE CASES (").append(list.size()).append(")\n");
            sb.append("=====================================\n");
            for (RescueCase rc : list) {
                sb.append(expand(rc)).append("\n-------------------------------------\n");
            }
            viewer("All Rescue Cases", sb.toString());
        }

        private static void printReport() {
            ArrayList<RescueCase> list = cabinet.files();
            StringBuilder sb = new StringBuilder();
            sb.append("=====================================\n");
            sb.append("WILDLIFE RESCUE REPORT\n");
            sb.append("=====================================\n");

            if (list.isEmpty()) {
                sb.append("No rescue cases to report.\n");
            } else {
                for (RescueCase rc : list) {
                    sb.append("Case ID          : ").append(rc.ticket()).append("\n");
                    sb.append("Type             : ").append(rc.label()).append("\n");
                    sb.append("Species          : ").append(rc.kind()).append("\n");
                    sb.append("Location         : ").append(rc.place()).append("\n");
                    sb.append("Ranger           : ").append(rc.keeper()).append("\n");
                    sb.append("Priority         : ").append(rc.severity()).append("\n");
                    sb.append("Status           : ").append(rc.phase()).append("\n");
                    sb.append("Total Cost       : ").append(RescueCase.rands(rc.grandTotal())).append("\n");
                    sb.append("-------------------------------------\n");
                }
            }
            sb.append("=====================================\n");
            sb.append("Total Cases      : ").append(cabinet.tally()).append("\n");
            sb.append("Total Cost       : ").append(RescueCase.rands(cabinet.totalWorth())).append("\n");
            sb.append("=====================================\n");
            viewer("Wildlife Rescue Report", sb.toString());
        }

        private static String expand(RescueCase rc) {
            return "Case ID           : " + rc.ticket() + "\n" +
                   "Animal Name       : " + rc.creature() + "\n" +
                   "Type              : " + rc.label() + "\n" +
                   "Species           : " + rc.kind() + "\n" +
                   "Location          : " + rc.place() + "\n" +
                   "Ranger            : " + rc.keeper() + "\n" +
                   "Days              : " + rc.days() + "\n" +
                   "Daily Cost        : " + RescueCase.rands(rc.rate()) + "\n" +
                   "Status            : " + rc.phase() + "\n" +
                   "Priority          : " + rc.severity() + "\n" +
                   rc.specifics() + "\n" +
                   "Total Cost        : " + RescueCase.rands(rc.grandTotal()) + "\n";
        }

        private static void viewer(String title, String body) {
            JTextArea area = new JTextArea(body);
            area.setEditable(false);
            area.setFont(new java.awt.Font("Monospaced", java.awt.Font.PLAIN, 12));
            JScrollPane scroll = new JScrollPane(area);
            scroll.setPreferredSize(new Dimension(560, 440));
            JOptionPane.showMessageDialog(null, scroll, title, JOptionPane.INFORMATION_MESSAGE);
        }

        // --- validated input helpers ---

        private static String prompt(String msg) {
            while (true) {
                String s = JOptionPane.showInputDialog(null, msg, "WildLife SA", JOptionPane.QUESTION_MESSAGE);
                if (s == null) return null;
                if (!s.trim().isEmpty()) return s.trim();
                notify("Cannot be blank.");
            }
        }

        private static Integer promptInt(String msg) {
            while (true) {
                String s = JOptionPane.showInputDialog(null, msg, "WildLife SA", JOptionPane.QUESTION_MESSAGE);
                if (s == null) return null;
                try {
                    int v = Integer.parseInt(s.trim());
                    if (v > 0) return v;
                    notify("Must be greater than zero.");
                } catch (NumberFormatException e) {
                    notify("Enter a whole number.");
                }
            }
        }

        private static Double promptDouble(String msg) {
            while (true) {
                String s = JOptionPane.showInputDialog(null, msg, "WildLife SA", JOptionPane.QUESTION_MESSAGE);
                if (s == null) return null;
                try {
                    double v = Double.parseDouble(s.trim());
                    if (v > 0) return v;
                    notify("Must be greater than zero.");
                } catch (NumberFormatException e) {
                    notify("Enter a number.");
                }
            }
        }

        private static Double promptAmount(String msg) {
            while (true) {
                String s = JOptionPane.showInputDialog(null, msg, "WildLife SA", JOptionPane.QUESTION_MESSAGE);
                if (s == null) return null;
                try {
                    double v = Double.parseDouble(s.trim());
                    if (v >= 0) return v;
                    notify("Cannot be negative.");
                } catch (NumberFormatException e) {
                    notify("Enter a number.");
                }
            }
        }

        private static boolean confirm(String msg) {
            return JOptionPane.showConfirmDialog(null, msg, "WildLife SA",
                    JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION;
        }

        private static void notify(String msg) {
            JOptionPane.showMessageDialog(null, msg, "WildLife SA", JOptionPane.INFORMATION_MESSAGE);
        }
    }
}